using UnityEngine;

public class GrowableManager : MonoBehaviour
{
    [SerializeField] private GameObject prefab;
    [SerializeField] private Vector2 xBound;
    [SerializeField] private Vector2 yBound;
    [SerializeField] private int count;

    private void Start()
    {
        for (int i = 0; i < count; i++)
        {
            GameObject cylinder = Instantiate(prefab, transform);
            cylinder.transform.position = new Vector3(Random.Range(xBound.x, xBound.y), 0, Random.Range(yBound.x, yBound.y));
        }
    }
}